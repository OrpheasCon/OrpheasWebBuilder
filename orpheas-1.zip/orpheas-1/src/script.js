(function(){

  // ── Hero particle canvas ──────────────────────────────────────────
  const hc = document.getElementById('hero-canvas');
  const hx = hc.getContext('2d');
  let hw, hh, hp = [];

  function rsH() {
    hw = hc.width = hc.offsetWidth;
    hh = hc.height = hc.offsetHeight;
  }

  function mkHP() {
    hp = [];
    const n = Math.floor(hw * hh / 7500);
    for (let i = 0; i < n; i++) {
      const pick = Math.random();
      const col = pick < 0.5 ? '201,168,76' : pick < 0.8 ? '168,176,188' : '220,210,190';
      hp.push({
        x: Math.random() * hw,
        y: Math.random() * hh,
        r: Math.random() * 5 + 3,
        vx: (Math.random() - .5) * .35,
        vy: (Math.random() - .5) * .35,
        o: Math.random() * .5 + .2,
        c: col
      });
    }
  }

  let mx = -9999, my = -9999;
  document.getElementById('hero').addEventListener('mousemove', e => {
    const r = hc.getBoundingClientRect();
    mx = e.clientX - r.left;
    my = e.clientY - r.top;
  });
  document.getElementById('hero').addEventListener('mouseleave', () => {
    mx = -9999; my = -9999;
  });

  function drawH() {
    hx.clearRect(0, 0, hw, hh);
    for (let i = 0; i < hp.length; i++) {
      const p = hp[i];
      p.x += p.vx; p.y += p.vy;
      if (p.x < 0) p.x = hw; if (p.x > hw) p.x = 0;
      if (p.y < 0) p.y = hh; if (p.y > hh) p.y = 0;
      const dx = p.x - mx, dy = p.y - my, d = Math.sqrt(dx * dx + dy * dy);
      if (d < 100 && d > 0) { p.x += dx / d * 2; p.y += dy / d * 2; }
      hx.beginPath();
      hx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      hx.fillStyle = `rgba(${p.c},${p.o})`;
      hx.fill();
      for (let j = i + 1; j < hp.length; j++) {
        const q = hp[j], dx2 = p.x - q.x, dy2 = p.y - q.y, d2 = Math.sqrt(dx2 * dx2 + dy2 * dy2);
        if (d2 < 140) {
          hx.beginPath(); hx.moveTo(p.x, p.y); hx.lineTo(q.x, q.y);
          hx.strokeStyle = `rgba(201,168,76,${.1 * (1 - d2 / 140)})`;
          hx.lineWidth = .5; hx.stroke();
        }
      }
    }
    requestAnimationFrame(drawH);
  }

  rsH(); mkHP(); drawH();
  window.addEventListener('resize', () => { rsH(); mkHP(); });

  // ── Contact particle canvas ───────────────────────────────────────
  const cc = document.getElementById('contact-canvas');
  const cx = cc.getContext('2d');
  let cw, ch, cp = [];

  function rsC() {
    cw = cc.width = cc.offsetWidth;
    ch = cc.height = cc.offsetHeight;
  }

  function mkCP() {
    cp = [];
    const n = Math.floor(cw * ch / 5000);
    for (let i = 0; i < n; i++) {
      const col = Math.random() < 0.6 ? '201,168,76' : '168,176,188';
      cp.push({
        x: Math.random() * cw,
        y: Math.random() * ch,
        r: Math.random() * 2.5 + 1,
        vx: (Math.random() - .5) * .25,
        vy: (Math.random() - .5) * .25,
        c: col
      });
    }
  }

  function drawC() {
    cx.clearRect(0, 0, cw, ch);
    for (let i = 0; i < cp.length; i++) {
      const p = cp[i];
      p.x += p.vx; p.y += p.vy;
      if (p.x < 0) p.x = cw; if (p.x > cw) p.x = 0;
      if (p.y < 0) p.y = ch; if (p.y > ch) p.y = 0;
      cx.beginPath();
      cx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      cx.fillStyle = `rgba(${p.c},.55)`;
      cx.fill();
    }
    requestAnimationFrame(drawC);
  }

  rsC(); mkCP(); drawC();

  // ── 3D card tilt ─────────────────────────────────────────────────
  document.querySelectorAll('.service-card').forEach(card => {
    card.addEventListener('mousemove', e => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left, y = e.clientY - rect.top;
      const cx2 = rect.width / 2, cy2 = rect.height / 2;
      const rX = -(y - cy2) / cy2 * 12;
      const rY = (x - cx2) / cx2 * 12;
      const shimmer = card.querySelector('.card-shimmer');
      if (shimmer) {
        shimmer.style.setProperty('--mx', `${(x / rect.width) * 100}%`);
        shimmer.style.setProperty('--my', `${(y / rect.height) * 100}%`);
      }
      card.style.transform = `perspective(800px) rotateX(${rX}deg) rotateY(${rY}deg) translateZ(8px)`;
    });
    card.addEventListener('mouseleave', () => {
      card.style.transition = 'transform .5s cubic-bezier(.23,1,.32,1),border-color .3s,box-shadow .3s';
      card.style.transform = 'perspective(800px) rotateX(0deg) rotateY(0deg) translateZ(0)';
      setTimeout(() => card.style.transition = '', 500);
    });
    card.addEventListener('mouseenter', () => { card.style.transition = 'none'; });
  });

  // ── Scroll reveal ─────────────────────────────────────────────────
  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        const el = e.target;
        const d = Number(el.dataset.delay || 0);
        setTimeout(() => el.classList.add('visible'), d);
        obs.unobserve(el);
      }
    });
  }, { threshold: .13 });

  document.querySelectorAll('.reveal').forEach(el => obs.observe(el));
  document.querySelectorAll('.process-item').forEach((el, i) => {
    el.dataset.delay = i * 130;
    obs.observe(el);
  });

})();